import React, { Component } from 'react';
import './Stock.css';

class Stock extends Component {

  constructor(props) {
    super(props);
    const { symbol } = this.props.datistock;
    this.state = { symbol,
            openprice: 0,
            datatrade: 'XXXX-XX-XXT09:00:00+0000', 
            ckrealtime: '' 
    };
  }

  static getDerivedStateFromProps(np,ns) {
    //  console.log('1fa) FIGLIO check props ');
     // if(np.datistock.quotazione !== ns.quotazione && np.datistock.nome!== ns.nome) {
     //   return { nome: np.datistock.nome, quotazione: np.datistock.quotazione };
     // }
      return null;
  }

  componentDidMount() {
     console.log('3f) FIGLIO DidMount ');
  }

  componentDidUpdate(pp,ps) {
    console.log('4f) FIGLIO – DidUpdate ' + this.props.datistock.nome);
    // if (pp.datistock.quotazione !== this.props.datistock.quotazione){
    //   this.setState((state,props) => 
    //                 ({ quotazione: props.datistock.quotazione }));
    // }
   }  

  getNewPrice = () => {
    // NB: devi usare la tua access_key, ottenuta previa registrazione sul sito di marketstack
    //const apiUrl = 'http://api.marketstack.com/v1/intraday?symbol=' + str + '&access_key=XXXX';
    // NB: In alterntiva puoi usare la nostra API di test che restituisce sempre dei dati fittizi per le azioni apple o amazon
    // NB: Devi attivare le richieste CORS nel browser
    const apiUrl = 'https://www.dcopelli.it/test/api/react/v2/intraday?symbol=' + this.props.datistock.symbol + "&minuti=31";
    fetch(apiUrl) 
    .then(r => r.json())
    .then(r => {
       const { data } = r;
       const datatrade = data[0].date;
       const price = data[0].close;
       if (this.state.openprice === 0) {
        this.setState({ price, datatrade, openprice: price })
        } else {
        this.setState({ price, datatrade });
       }
      }
    )
    .catch(error=>{console.log('Errore caricamento' + error)})
  }

  eliminoStock = () => {
    this.props.eliminoStock(this.props.datistock.id);
  }

  startRealTime = () => {
   this.timer = setInterval(() => this.getNewPrice(), 60000);
  } 

  stopRealTime = () => {
   clearInterval(this.timer);
  }

  startStopRealTime = () => {
  const ckrt = this.state.ckrealtime === 'checked' ? '' : 'checked';
    if (ckrt === 'checked') {
      this.startRealTime();
    } else {
      this.stopRealTime();
    }
  this.setState({ckrealtime: ckrt});
  }
  
  render() {
    const { price, openprice, datatrade } = this.state
    const diff = price - openprice
    const diffperc = openprice ? (diff/openprice)*100 : 0;
    console.log('2f) FIGLIO Render ' + this.props.datistock.symbol);
    return (
      <div className="stock col-md-6">
      <div className="bodystock m-1 p-3">
      <i className="fas fa-times-circle closebtn" onClick={this.eliminoStock}></i>
      <div className="row">
        <div className="col-sm">
          <h2>{this.props.datistock.symbol}</h2>
          <p>Nasdaq</p>
        </div>
        <div className="col-sm">
          <h2>{price}</h2>
          <p>{datatrade.substr(11,8)}</p>
        </div>
        <div className="col-sm">
          <h2>{diffperc.toFixed(2)} %</h2>
          <p>{diff.toFixed(1)}</p>
        </div>
        <div className="col-sm">
        <h2>
          <i className="fas fa-sync-alt"></i>
        </h2>
        <label className="bs-switch">
          <input type="checkbox" 
                     checked={this.state.ckrealtime}
                     onChange={this.startStopRealTime} />
          <span className="slider round"></span>
        </label>
        </div>
      </div>
      </div>
      </div>
    )
  }
}

export default Stock

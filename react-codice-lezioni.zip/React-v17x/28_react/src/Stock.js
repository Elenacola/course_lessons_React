import React, { Component } from 'react';
import Grafico from './Grafico';
import './Stock.css';

class Stock extends Component {

    constructor(props) {
     super(props);
     const { symbol, price } = this.props.datistock;
     this.state = { symbol,
                    openprice: 0,
                    datatrade: 'XXXX-XX-XXT09:00:00+0000', 
                    ckrealtime: '',
                    datigrafico: [{datetime: '08:00:00', price: 0}], 
                    showgrafico: false 
                   };
     }
    
     startRealTime = () => {
      this.timer = setInterval(() => this.getNewPrice(), 60000);
     } 
    
     stopRealTime = () => {
      clearInterval(this.timer);
     }
     
     startStopRealTime = () => {
      const ckrt = this.state.ckrealtime === 'checked' ? '' : 'checked';
      if (ckrt === 'checked') {
        this.startRealTime();
      } else {
        this.stopRealTime();
      }
      this.setState({ckrealtime: ckrt});
     }
    
     getNewPrice = () => {
       // NB: devi usare la tua access_key, ottenuta previa registrazione sul sito di marketstack
       //const apiUrl = 'http://api.marketstack.com/v1/intraday?symbol=' + str + '&access_key=XXXX';
       // NB: In alterntiva puoi usare la nostra API di test che restituisce sempre dei dati fittizi per le azioni apple o amazon
       // NB: Devi attivare le richieste CORS nel browser
       const apiUrl = 'https://www.dcopelli.it/test/api/react/v2/intraday?symbol=' + this.props.datistock.symbol + "&minuti=31";
       fetch(apiUrl) 
       .then(r => r.json())
       .then(r => {
                    const { data } = r;
                    const datatrade = data[0].date;
                    const price = data[0].close;
                    if (this.state.openprice === 0) {
                      const datigrafico = [{datetime: datatrade.substr(11,8), price}];
                      this.setState({ price, datatrade, openprice: price, datigrafico })
                    } else {
                      const datigrafico = [...this.state.datigrafico, {datetime: datatrade.substr(11,8), price}];
                      this.setState({ price, datatrade, datigrafico });
                    }              
                 }
              )
       .catch(error=>{console.log('Errore caricamento' + error)})
     } 
    
     componentWillUnmount = () => {
       this.stopRealTime();
     }
   
     showGrafico = () => {
       this.setState({showgrafico: !this.state.showgrafico});
     }
     
     eliminoStock = () => {
      this.props.eliminoStock(this.props.datistock.id);
     }
    
     render() {
      const { price, openprice, datatrade } = this.state
      const diff = price - openprice
      const diffperc = openprice ? (diff/openprice)*100 : 0;
      console.log('2f) FIGLIO Render ' + this.props.datistock.symbol);
      return (
        <div className="stock col-md-6">
         <div className="bodystock m-1 p-3">
          <i className="fas fa-times-circle closebtn" onClick={this.eliminoStock}></i>
          <div className="row">
            <div className="col-sm">
              <h2>{this.props.datistock.symbol}</h2>
              <p>Nasdaq</p>
            </div>
            <div className="col-sm">
              <h2>{price}</h2>
             <p>{datatrade.substr(11,8)}</p>
            </div>
            <div className="col-sm">
              <h2>{diffperc.toFixed(2)} %</h2>
              <p>{diff.toFixed(1)}</p>
            </div>
            <div className="col-sm">
              <h2 onClick={this.showGrafico}>
               <i className="fas fa-chart-line fa-2x"></i>
              </h2>
              <label className="bs-switch">
                  <input type="checkbox" 
                         checked={this.state.ckrealtime}
                         onChange={this.startStopRealTime} />
                  <span className="slider round"></span>
              </label>
            </div>
           </div>
          </div>        
          <div className="bodygrafico">
            <div className="row">
              <div className="col">
                { this.state.showgrafico && <div className="grafico"><Grafico datistock={this.state.datigrafico}/></div> }
              </div>
            </div>
          </div>
       </div>   
      );
    }
}    
export default Stock;
    

import React, { Component } from 'react';
import './App.css';
import Cerca from './Cerca';
import NomeStock from './NomeStock';
import Stock from './Stock';

// Capitolo 28

class App extends Component {

  constructor(props) {
    super(props);
    this.state = { listaelementi : [], listapreferiti: [], inCaricamento: false, showError: false, msgError: null, cont:0};
    console.log('1g) Creo istanza GENITORE');
  }
  
  cercaElementi = (strcerca) => {
    this.getElementi(strcerca);
  }

  getElementi = (str) => {
    this.setState({inCaricamento: true,  showError: false});
    // NB: devi usare la tua access_key, ottenuta previa registrazione sul sito di marketstack
    const apiUrl = 'http://api.marketstack.com/v1/tickers?search=' + str + '&access_key=XXXXX';
    // In alternativa puoi usare la nostra api di test
    //const apiUrl = 'https://www.dcopelli.it/test/api/react/v1/stock_search/?search_term=' + str;  
    fetch(apiUrl)
    .then(r => r.json())
    .then(r => {
      const { data } = r;
      console.log('Recupero dati ' + JSON.stringify(data));
      this.setState({ listaelementi : data, inCaricamento: false});
    })
    .catch((error) => {
      console.log('Fetch failed', error);
      this.setState({
        inCaricamento: false, 
        showError: true,
        msgError: error.message
       });
    });
  }

  onAddPreferiti = (ids) => {
    //alert('ID elemento cliccato ' + ids);
    const stock  = this.state.listaelementi[ids];
    const contatore = this.state.cont + 1;
    stock['id'] = contatore;
    console.log(JSON.stringify(stock));
    this.setState({ listapreferiti: [...this.state.listapreferiti, stock], cont: contatore });
  }

  elimino = (id) => {
    console.log('Cancello ' + id);
    if (id) { 
     const preferiti = this.state.listapreferiti.filter(el => {
                         if (el.id !== id) return el;
                         return false;
                       });
     this.setState({listapreferiti: preferiti});
    }
  }
  
  render() {
    console.log('2g) GENITORE  Render App');
    return (
      <div className="App container-fluid">
       <header className="App-header">
          <p>
            Applicazione NasdaqReact
          </p>
          <Cerca onInputSearch={this.cercaElementi} />
          {this.state.showError && 
             <p className="text-center">{this.state.msgError}</p>}
          {this.state.inCaricamento && 
             <p className="text-center">Caricamento in corso</p>}

          <div className="container">
           <section className="listanomi">
            <div className="row">
              <div className="col">
                {this.state.listaelementi.map((el, index) => 
                     <NomeStock key={el.symbol} datistock={el} ids={index} onAddPreferiti={this.onAddPreferiti}/>)}
              </div>
            </div>
           </section>
           <section className="listapreferiti">
            <div className="row">
                 {this.state.listapreferiti.map((el, index) => 
                     <Stock key={el.symbol} datistock={el} eliminoStock={this.elimino}/>)}
            </div>
           </section>
          </div> 
       </header>  
       </div>
    );
  }
}

export default App;

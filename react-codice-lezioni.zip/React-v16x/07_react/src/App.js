import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Figlio from './Figlio'

class App extends Component {

    constructor(props) {
      super(props);
      this.state = {eta : 10, hobby: ['Calcio', 'Libri', 'Tennis']};
      setInterval(()=> this.aggiornoEta(), 3000);
    } 


    
  aggiornoEta = () => {    
    const neh = [...this.state.hobby, this.state.eta.toString()]
    this.setState({eta: this.state.eta + 1, hobby: neh});
  }
showMsg = () => {
  alert('Un figlio è diventato maggiorenne');
}

  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <p>
            Applicazione React {this.state.eta}
          </p>
          {this.state.hobby.map(el =>  <Figlio nome={el} />)}
            <Figlio nome="Apple" cognome="Jobs" eta={this.state.eta} sonoMaggiorenne={this.showMsg}></Figlio>
            <Figlio nome="Google" cognome="Brin" eta={56} sonoMaggiorenne={this.showMsg}></Figlio>
        </header>
      </div>
    );
  }
}

export default App;

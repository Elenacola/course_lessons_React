import React, { Component } from 'react'

class Figlio extends Component {
  constructor(props) {
      super(props);
      this.state = {eta : this.props.eta, hobby: ['Calcio', 'Libri', 'Tennis']};      
      this.showToast1 = this.showToast1.bind(this);               
    } 
    
    realTime = () => {      
      setInterval(()=> this.aggiornoEta(), 3000);
    }
    
    aggiornoEta = () => {    
      this.setState((state,props) => ({eta: state.eta + 1}));    
    }

    showToast = (e) => {
      // console.log(e.pageX);
      alert('Hai cliccato sul componente ' + this.props.nome);
    }
    
    showToast1(e) {
      alert('Hai cliccato sul componente ' + this.props.nome);
    }


  render() {
    const { nome, cognome } = this.props;
    return (
      <div>
        <h1 onClick={this.showToast1}>Il sono il Figlio {nome.toUpperCase()} {cognome} Età: {this.state.eta}</h1>
        <button onClick={this.realTime}>START</button>
        <ul>
          {/* { hobby.map( item => <li>{item}</li>) } */}
        </ul>
      </div>
    );
  }
}

// const Figlio = (props) => {
//     return (
//          <div>
//             <h1>Mio Figlio {props.nome} {props.cognome}</h1>
//          </div>
//     )
// }

export default Figlio

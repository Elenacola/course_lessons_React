import React, { Component } from 'react'

class Figlio extends Component {
  constructor(props) {
      super(props);
      this.state = {eta : this.props.eta, hobby: ['Calcio', 'Libri', 'Tennis']};      
      //setInterval(()=> this.aggiornoEta(), 3000);               
  }  

  aggiornoStato = () => {    
    this.setState((state,props) => ({eta: state.eta + 1}));    
  }

  showCoordinate = (e) => {
    console.log('X:'+ e.pageX);
  }

  render() {
    const { nome, cognome } = this.props;
    return (
      <div>
        <h1 onMouseMove={this.showCoordinate}>Il sono il Figlio {nome.toUpperCase()} {cognome} Età: {this.state.eta} 
        <button onClick={this.aggiornoStato}>{this.state.eta<=18 ? '+' : '-'}</button></h1>
        <ul>
          { this.state.hobby.map( item => <li>{item}</li>) }
        </ul>
      </div>
    );
  }
}

// const Figlio = (props) => {
//     return (
//          <div>
//             <h1>Mio Figlio {props.nome} {props.cognome}</h1>
//          </div>
//     )
// }

export default Figlio

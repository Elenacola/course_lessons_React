import React, { Component } from 'react';
import './App.css';
import Stock from './Stock';
import NomeStock from './NomeStock';
import Cerca from './Cerca';
import logo from './logo.svg'


class App extends Component {
 
  constructor(props) {
    super(props);
    this.state = { listaelementi: [],  listapreferiti: []};
    console.log('1g) Creo istanza GENITORE');
  }
  
  // CREAZIONE -------------------------------------------
  
  componentDidMount() {
    console.log('3g) GENITORE DidMount ');
    // const stock = [{ nome : 'AAPL', valore : 250},{ nome: 'GOOG', valore: 1200}];
    // this.setState({listastock: stock});
  }

  // AGGIORNAMENTO ---------------------------------------

  // static getDerivedStateFromProps(np,ps) {
  //   return null;
  // }

  // componentDidUpdate(prevProps) {
  //   console.log('4g) Did update Padre');
  // }

  //----------------------------------------------------------

  // aggiornoStock = (e) => {
  //   const stock1 = [
  //       {nome : 'AMZ', valore : 125},
  //       {nome: 'GOOG', valore: 1200},
  //       {nome: 'AAPL', valore: 270}
  //   ];
  //   e.preventDefault();    
  //   this.setState({listastock : stock1});
  // }

  cercaElementi = (strcerca) => {
    //alert('Stai cercando ' + strcerca);
    this.getElementi(strcerca);
  }

  getElementi = (str) => {
    const apiUrl = 'https://www.worldtradingdata.com/api/v1/stock_search?search_term=' + str + '&search_by=symbol,name&limit=50&page=1&api_token=OCQiyioLhQrVqG464JmXB8A2MTNBrYbIUsNtLolLj3EDsvhSWNRl96Lt86ov'; 
    fetch(apiUrl)
    .then(r => r.json())
    .then(r => {
      const { data } = r;
      this.setState({ listaelementi: data });
      console.log('Recupero dati ' + JSON.stringify(data));
    })
    .catch((error) => {
      console.log('Fetch failed', error);
    });
  }


  render() {
    console.log('2g) GENITORE  Render');
    return (
      <div className="App container-fluid">
        <header className="App-header">
        <img src={logo} className="App-logo" alt="Nasdaq WebApp" />
          <p>
            Applicazione Stock Quote
          </p>
          <Cerca onInputSearch={this.cercaElementi} />
          <div className="container">
           <section className="listanomi">
              <div className="row">
                <div className="col">
                  { this.state.listaelementi.map(el => <NomeStock key={el.symbol} dati={el}/>) }                  
                </div>
              </div>
            </section>    
           <section className="listapreferiti">
              <div className="row">
                <div className="col">
                  { this.state.listapreferiti.map(el => <Stock key={el.nome} dati={el}/>) }
                </div>
              </div>
            </section>    
          </div>
        </header>
      </div>
    );
  }
}

export default App;

import React, { Component } from 'react'

class Figlio extends Component {
  constructor(props) {
      super(props);
      console.log(this.props.nome);
  }  
  render() {
    return (
      <div>
        <h1>Il sono il Figlio {this.props.nome} {this.props.cognome}</h1>
      </div>
    )
  }
}

// const Figlio = (props) => {
//     return (
//          <div>
//             <h1>Mio Figlio {props.nome} {props.cognome}</h1>
//          </div>
//     )
// }

export default Figlio

import React, { Component } from 'react';
import './App.css';
import Grafico from './Grafico';

// Capitolo 27

const data = [
  {datetime: '09:00:00', price: 4000},
  {datetime: '09:01:00', price: 3000},
  {datetime: '09:02:00', price: 2000},
  {datetime: '09:03:00', price: 2780},
  {datetime: '09:04:00', price: 1890},
  {datetime: '09:05:00', price: 2390},
  {datetime: '09:06:00', price: 3490},
];

class App extends Component {
 
  render() {
    return (
      <div className="App container-fluid">
        <header className="App-header">
          <p>
            Esempio di grafico
          </p>
          <Grafico datistock={data} />
        </header>  
      </div>
    );
  }
}

export default App;

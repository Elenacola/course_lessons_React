import React, { Component } from 'react';
import Grafico from './Grafico';
import './Stock.css';

class Stock extends Component {

    constructor(props) {
     super(props);
     const { symbol, price } = this.props.datistock;
     this.state = { symbol,
                     price, 
                    datatrade: 'XXXX-XX-XX 16:00:00', 
                    ckrealtime: '', 
                    datigrafico: [{datetime: '16:00:00', price: price}], 
                    showgrafico: false 
                   };
     }
    
     startRealTime = () => {
      this.timer = setInterval(() => this.getNewPrice(), 60000);
     } 
    
     stopRealTime = () => {
      clearInterval(this.timer);
     }
     
     startStopRealTime = () => {
      const ckrt = this.state.ckrealtime === 'checked' ? '' : 'checked';
      if (ckrt === 'checked') {
        this.startRealTime();
      } else {
        this.stopRealTime();
      }
      this.setState({ckrealtime: ckrt});
     }
    
     getNewPrice = () => {
    // NB: Le API del sito worldtradingdata sono  cambiate quindi abbbiamo creato un'API di test nel nostro sito
    // Per maggiori informazioni leggi la news nell'area WebSU, dove hai scaricato questo codice
       const apiUrl = 'https://www.dcopelli.it/test/api/react/v1/intraday?symbol=' + this.props.datistock.symbol;
       fetch(apiUrl) 
       .then(r => r.json())
       .then(r => {
                 console.log(JSON.stringify(r));
                 const { intraday } = r;
                 const timeprice = Object.entries(intraday)[0];
                 const datatrade = timeprice[0];
                 const price = timeprice[1].open;
                 const datigrafico = [...this.state.datigrafico, {datetime: datatrade.substr(11), price: price}];
                 this.setState({ price, datatrade, datigrafico });
                 }
              )
       .catch(error=>{console.log('Errore caricamento' + error)})
     } 
    
     componentWillUnmount = () => {
       this.stopRealTime();
     }
   
     showGrafico = () => {
       this.setState({showgrafico: !this.state.showgrafico});
     }
     
     eliminoStock = () => {
      this.props.eliminoStock(this.props.datistock.id);
     }
    
     render() {
      const diff = (this.state.price - this.props.datistock.price).toFixed(2)
      const diffperc = (this.props.datistock.price) ?
                         (diff/this.props.datistock.price*100).toFixed(1) : '-';
      console.log('2f) FIGLIO Render ' + this.props.datistock.symbol);
      return (
        <div className="stock col-md-6">
         <div className="bodystock m-1 p-3">
          <i className="fas fa-times-circle closebtn" onClick={this.eliminoStock}></i>
          <div className="row">
            <div className="col-sm">
              <h2>{this.props.datistock.symbol}</h2>
              <p>Nasdaq</p>
            </div>
            <div className="col-sm">
              <h2>{this.state.price}</h2>
              <p>{this.state.datatrade.substr(11)}</p>
            </div>
            <div className="col-sm">
              <h2>{diffperc} %</h2>
              <p>{diff}</p>
            </div>
            <div className="col-sm">
              <h2 onClick={this.showGrafico}>
               <i className="fas fa-chart-line"></i>
              </h2>
              <label className="bs-switch">
                  <input type="checkbox" 
                         checked={this.state.ckrealtime}
                         onChange={this.startStopRealTime} />
                  <span className="slider round"></span>
              </label>
            </div>
           </div>
          </div>        
          <div className="bodygrafico">
            <div className="row">
              <div className="col">
                { this.state.showgrafico && <div className="grafico"><Grafico datistock={this.state.datigrafico}/></div> }
              </div>
            </div>
          </div>
       </div>   
      );
    }
}    
export default Stock;
    

import React, { Component } from 'react';
import './Stock.css';

class Stock extends Component {

  constructor(props) {
    super(props);
    const { symbol, price } = this.props.datistock;
    this.state = { symbol, price };
    console.log('1f) FIGLIO Creo istanza');
  }

  static getDerivedStateFromProps(np,ns) {
    //  console.log('1fa) FIGLIO check props ');
     // if(np.datistock.quotazione !== ns.quotazione && np.datistock.nome!== ns.nome) {
     //   return { nome: np.datistock.nome, quotazione: np.datistock.quotazione };
     // }
     return null;
  }

  componentDidMount() {
     console.log('3f) FIGLIO DidMount ');
  }

  componentDidUpdate(pp,ps) {
    console.log('4f) FIGLIO – DidUpdate ' + this.props.datistock.nome);
    // if (pp.datistock.quotazione !== this.props.datistock.quotazione){
    //   this.setState((state,props) => 
    //                 ({ quotazione: props.datistock.quotazione }));
    // }
   }  

  aggiornoStock = () => {
    this.setState((state,props) => ({ quotazione: state.quotazione + 10 }));
  }

  eliminoStock = () => {
    this.props.eliminoStock(this.props.datistock.id);
  }

  
  render() {
    console.log('2f) FIGLIO Render ' + this.props.datistock.symbol);
    return (
      <div className="stock col-md-6">
      <div className="bodystock m-1 p-3">
      <i className="fas fa-times-circle closebtn" onClick={this.eliminoStock}></i>
      <div className="row">
        <div className="col-sm">
          <h2>{this.props.datistock.symbol}</h2>
          <p>Nasdaq</p>
        </div>
        <div className="col-sm">
          <h2>{this.state.price}</h2>
          <p>HH:MM:SS</p>
        </div>
        <div className="col-sm">
          <h2>Var</h2>
          <p>%</p>
        </div>
        <div className="col-sm">
        <h2 onClick={this.aggiornoStock}>
              <i className="fas fa-sync-alt fa-2x"></i>
        </h2>
        </div>
      </div>
      </div>
      </div>
    )
  }
}

export default Stock

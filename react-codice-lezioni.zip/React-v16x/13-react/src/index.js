import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import { LineChart, Line } from 'recharts';

ReactDOM.render(<App nome="Davide"/>, document.getElementById('root'));


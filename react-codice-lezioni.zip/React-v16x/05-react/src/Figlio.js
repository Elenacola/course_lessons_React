import React, { Component } from 'react'

class Figlio extends Component {
  constructor(props) {
      super(props);
      this.eta = this.props.eta;
      console.log(typeof(this.eta));
  }  
  render() {
    const { nome, cognome } = this.props;
    const hobby = ['Calcio', 'Libri', 'Tennis'];
    const itemJSX =  (
                       <ul>
                          { hobby.map( item => <li>{item}</li>) }
                       </ul>
                     ); 
    setInterval(()=> { this.eta++; console.log(this.eta) }, 3000);                 
    return (
      <div>
        <h1>Il sono il Figlio {nome.toUpperCase()} {cognome} Età: {this.eta}</h1>
        { this.eta> 18 ?  <h2>Sono maggiorenne</h2> : <h2> Sono minorenne</h2> }
        { this.eta> 18 &&  <h2>Sono maggiorenne</h2>  }
        <ul>
          { hobby.map( item => <li>{item}</li>) }
        </ul>
        {itemJSX}
      </div>
    );
  }
}

// const Figlio = (props) => {
//     return (
//          <div>
//             <h1>Mio Figlio {props.nome} {props.cognome}</h1>
//          </div>
//     )
// }

export default Figlio

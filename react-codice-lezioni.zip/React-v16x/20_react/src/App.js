import React, { Component } from 'react';
import './App.css';
import Stock from './Stock';
import NomeStock from './NomeStock';
import Cerca from './Cerca';
import logo from './logo.svg'

class App extends Component {
 
  constructor(props) {
    super(props);
    this.state = { listaelementi: [],  listapreferiti: [], inCaricamento: false, showError: false, msg: null};
    console.log('1g) Creo istanza GENITORE');
  }
   
  componentDidMount() {
    console.log('3g) GENITORE DidMount ');
  }

  cercaElementi = (strcerca) => {
    this.getElementi(strcerca);
  }

  getElementi = (str) => {
    const apiUrl = 'https://www.worldtradingdata.com/api/v1/stock_search?search_term=' + str + '&search_by=symbol,name&limit=50&page=1&api_token=OCQiyioLhQrVqG464JmXB8A2MTNBrYbIUsNtLolLj3EDsvhSWNRl96Lt86ov'; 
    this.setState({inCaricamento: true, showError: false});
    fetch(apiUrl)
    .then(r => r.json())
    .then(r => {
      const { data } = r;
      this.setState({ listaelementi: data, inCaricamento: false });
      console.log('Recupero dati ' + JSON.stringify(data));
    })
    .catch((error) => {
      this.setState({ inCaricamento: false, showError: true, msg: error.message });
      console.log('Fetch failed', error);
    });
  }

  addPreferiti = (ids) => {
    alert('Ho selezionato elemento id: ' + ids);
    this.setState({listapreferiti: [...this.state.listapreferiti, this.state.listaelementi[ids]]})
  }

  render() {
    console.log('2g) GENITORE  Render');

    return (
      <div className="App container-fluid">
        <header className="App-header">
        <img src={logo} className="App-logo" alt="Nasdaq WebApp" />
          <p>
            Applicazione Stock Quote
          </p>
          <Cerca onInputSearch={this.cercaElementi} />
          <div className="container">
            <section className="listanomi">
              <div className="row">
                <div className="col">
                  { this.state.inCaricamento && <p className="text-center">Caricaricamento in corso...</p> }
                  { this.state.showError && <p className="text-center">{this.state.msg}</p> }
                  { this.state.listaelementi.map((el,index) => <NomeStock key={el.symbol} dati={el} ids={index} onAddPreferiti={this.addPreferiti}/>) }
                </div>
              </div>
            </section>
          </div>
          </header>
          <section className="listapreferiti mt-3">
              <div className="row">
                  { this.state.listapreferiti.map(el => <Stock key={el.nome} dati={el}/>) }
              </div>
          </section>  
      </div>
    );
  }
}

export default App;

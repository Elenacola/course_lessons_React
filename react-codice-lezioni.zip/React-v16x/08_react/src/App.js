import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Figlio from './Figlio'

import PropTypes from 'prop-types';

class App extends Component {

  showMsg = (nf) => {
    alert(nf + '  è diventato maggiorenne');
  }

  showSpostamento = (e) => {
    alert('Spostamento sul figlio ' + e)
  }

  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <p>
            Applicazione React 
          </p>
            <Figlio nome="Apple" cognome="Jobs" eta={16} sonoMaggiorenne={this.showMsg} getSpostamento={this.showSpostamento}></Figlio>
            <Figlio nome="Google" cognome="Brin" eta={56} sonoMaggiorenne={this.showMsg}></Figlio>
        </header>
      </div>
    );
  }
}

export default App;

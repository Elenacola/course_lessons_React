import React from 'react'
import './Stock.css';

 const NomeStock = props => {

    const addPreferiti = () => {
      props.onAddPreferiti(props.ids);
    }

    return (
      <div className="nomestock" onClick={addPreferiti}>
         <i className="fas fa-plus-circle"></i> {props.datistock.symbol} -  {props.datistock.name} 
      </div>
    );
}

export default NomeStock;

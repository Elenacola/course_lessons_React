import React, { Component } from 'react';
import './App.css';
import Stock from './Stock';

class App extends Component {

  constructor(props) {
    super(props);
    this.state = { nome: 'APPL', valore: 250};
    console.log('1g) Creo istanza GENITORE');
  }

  // CREAZIONE -------------------------------------------

  componentDidMount() {
   console.log('3g) GENITORE DidMount ');
  }

  // AGGIORNAMENTO ---------------------------------------

  // static getDerivedStateFromProps(np,ps) {
  //   return null;
  // }

  // componentDidUpdate(prevProps) {
  //   console.log('4g) Did update Padre');
  // }

  //----------------------------------------------------------

  aggiornoStock = (e) => {
    e.preventDefault();    
    this.setState({nome : 'GOOG'})
  }

  render() {
    console.log('2g) GENITORE  Render');
    return (
      <div className="App">
        <header className="App-header">
          <p>
            Applicazione Stock Quote - <a href="#" onClick={this.aggiornoStock}>Aggiorno</a>
          </p>
          <Stock nome={this.state.nome} valore={this.state.valore}/>
        </header>
      </div>
    );
  }
}

export default App;

import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import SearchForm from './SearchForm';

class App extends Component {

  constructor(props) {
    super(props);
    this.state = {nome :'Cerca'}
  }

  invioFormPadre = (cerca) => {
    alert('Messaggio dal padre. Hai cercato ' + cerca);
  }

  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <p>
            Applicazione React 
          </p>
          <SearchForm nome={this.state.nome} onSubmit={this.invioFormPadre}/>
        </header>
      </div>
    );
  }
}

export default App;

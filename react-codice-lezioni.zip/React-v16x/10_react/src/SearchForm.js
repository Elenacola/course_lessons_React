import React, { Component } from 'react'

class SearchForm extends Component {

  constructor(props) {
        super(props);
        this.state = { cerca : this.props.nome, note: '', azione: '', ck1: false, ck2: false};
  }

  onInput = (e) => {
      console.log(e.target.value);
      this.setState({cerca : e.target.value});
  }

  onChange = (e) => {
    console.log(e.target.value);
    this.setState({note : e.target.value});
  }

  onChangeSelect = (e) => {
    console.log(e.target.value);
    this.setState({azioni : e.target.value});
  }

  onChangeCk = (e) => {
    console.log("Ho cliccato sul campo checkbox " + e.target.name + ":" + e.target.checked);
    this.setState({[e.target.name] : e.target.checked});
  }

  invioForm = (e) => {
    e.preventDefault();
    // alert('I dati sono stati inviati' + this.state.cerca);
    this.props.onSubmit(this.state.cerca);
  }

  render() {
    return (
      <div>
        <form onSubmit={this.invioForm}>
         <p>
            <select name="azioni" value={this.state.azioni} onChange={this.onChangeSelect}>
              <option value="-">Seleziona</option>
              <option value="Apple">Apple</option>
              <option value="Google">Google</option>
            </select>
         </p>
         <p><input type="checkbox" name="ck1" checked={this.state.ck1} onChange={this.onChangeCk}/>C1 <input type="checkbox" name="ck2" checked={this.state.ck2} onChange={this.onChangeCk}/> C2</p>
         <p><input type="radio" /> R1 <input type="radio" /> R2</p>

         <p><input type="text" name="cerca" value={this.state.cerca} onChange={this.onInput} /></p>
         <p><textarea name="note" value={this.state.note} onChange={this.onChange}></textarea></p>
         <input type="submit" value="Invio dati"/> 
      </form>
      </div>
    )
  }
}

export default SearchForm

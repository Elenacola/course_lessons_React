import React, { Component } from 'react'

class Cerca extends Component {

  constructor(props){
      super(props);
      this.state = {
          camporicerca: ''
      }
  }

  onInputChange = e => {
      this.setState({ camporicerca : e.target.value})
  }

  invioForm = e => {
      e.preventDefault();
      this.props.onInputSearch(this.state.camporicerca);
      this.setState({camporicerca: ''});
  }

  onFocus = (e) => {
      e.target.blur();
  }

  render() {
    return (
      <div className="row">
        <form className="form-inline" onSubmit={this.invioForm}>
            <div className="form-group">
                <input 
                      type="text" 
                      name="cerca" 
                      value={this.state.camporicerca}
                      onChange={this.onInputChange} 
                      className="form-control mb-4 mr-sm-2"/>
            </div>
            <button type="submit" onFocus={this.onFocus} className="btn btn-primary mb-4">Ok</button>
        </form>
      </div>
    )
  }
}

export default Cerca

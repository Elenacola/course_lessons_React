import React, { Component } from 'react';
import './App.css';
import Cerca from './Cerca';
import NomeStock from './NomeStock';

// Capitolo 22

class App extends Component {

  constructor(props) {
    super(props);
    this.state = { listaelementi : [], listapreferiti: [] };
    console.log('1g) Creo istanza GENITORE');
  }
  
  cercaElementi = (strcerca) => {
    //alert('Stai cercando ' + strcerca);
    this.getElementi(strcerca);
  }

  getElementi = (str) => {
    this.setState({inCaricamento: true});
    // NB: Le API del sito worldtradingdata sono  cambiate quindi abbbiamo creato un'API di test nel nostro sito
    // Per maggiori informazioni leggi la news nell'area WebSU, dove hai scaricato questo codice
    const apiUrl = 'https://www.dcopelli.it/test/api/react/v1/stock_search?search_term=' + str; 
    fetch(apiUrl)
    .then(r => r.json())
    .then(r => {
      const { data } = r;
      console.log('Recupero dati ' + JSON.stringify(data));
      this.setState({ listaelementi : data  });
    })
    .catch((error) => {
      console.log('Fetch failed', error);
    });
  }

  render() {
    console.log('2g) GENITORE  Render App');
    return (
      <div className="App container-fluid">
        <header className="App-header">
          <p>
            Applicazione NasdaqReact
          </p>
          <Cerca onInputSearch={this.cercaElementi} />
          <div className="container">
          <section className="listanomi">
           <div className="row">
              <div className="col">
                {this.state.listaelementi.map(el => 
                                <NomeStock key={el.symbol} datistock={el} />)}
              </div>
          </div>
          </section>    
          <section className="listapreferiti">
              <div className="row">
                <div className="col">

                </div>
              </div>
           </section>
          </div>     
        </header>
      </div>
    );
  }
}

export default App;

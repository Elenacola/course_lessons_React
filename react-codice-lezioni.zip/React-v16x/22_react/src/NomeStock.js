import React from 'react'

function  NomeStock(props) {
    return (
      <div className="nomestock">
         <i className="fas fa-plus-circle"></i> {props.datistock.symbol} -  {props.datistock.name} 
      </div>
    );
}

export default NomeStock;

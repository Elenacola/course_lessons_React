import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';

ReactDOM.render('<h1>Genitore</h1>', document.getElementById('root'));


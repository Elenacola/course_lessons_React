import React, { Component } from 'react';
import './App.css';
import Stock from './Stock';
import Cerca from './Cerca';
import logo from './logo.svg'


class App extends Component {
 
  constructor(props) {
    super(props);
    this.state = { listastock: []};
    console.log('1g) Creo istanza GENITORE');
  }
  
  // CREAZIONE -------------------------------------------
  
  componentDidMount() {
    console.log('3g) GENITORE DidMount ');
    const stock = [{ nome : 'AAPL', valore : 250},{ nome: 'GOOG', valore: 1200}];
    this.setState({listastock: stock});
  }

  // AGGIORNAMENTO ---------------------------------------

  // static getDerivedStateFromProps(np,ps) {
  //   return null;
  // }

  // componentDidUpdate(prevProps) {
  //   console.log('4g) Did update Padre');
  // }

  //----------------------------------------------------------

  aggiornoStock = (e) => {
    const stock1 = [
        {nome : 'AMZ', valore : 125},
        {nome: 'GOOG', valore: 1200},
        {nome: 'AAPL', valore: 270}
    ];
    e.preventDefault();    
    this.setState({listastock : stock1});
  }

  cercaStock = (strcerca) => {
    alert('Staio cercando ' + strcerca);
  }

  render() {
    console.log('2g) GENITORE  Render');
    return (
      <div className="App container-fluid">
        <header className="App-header">
        <img src={logo} className="App-logo" alt="Nasdaq WebApp" />
          <p>
            Applicazione Stock Quote - <a href="#"  onClick={this.aggiornoStock}>Top Guadagno</a>
          </p>
          <Cerca onInputSearch={this.cercaStock} />
          <div className="container">
            <div className="row">
               { this.state.listastock.map(el => <Stock key={el.nome} dati={el}/>) }
            </div>
          </div>
        </header>
      </div>
    );
  }
}

export default App;

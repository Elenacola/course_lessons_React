import React, { Component } from 'react'

class SearchForm extends Component {
    constructor(props) {
        super(props);
        this.state = { cerca : this.props.nome, note: ''}
    }
  onInput = (e) => {
      console.log(e.target.value);
      this.setState({cerca : e.target.value});
  }
  onChange = (e) => {
    console.log(e.target.value);
    this.setState({note : e.target.value});
  }
  render() {
    return (
      <div>
         <input type="text" name="cerca" value={this.state.cerca} onInput={this.onInput}/>
         <textarea name="note" value={this.state.note} onChange={this.onChange} />
      </div>
    )
  }
}

export default SearchForm

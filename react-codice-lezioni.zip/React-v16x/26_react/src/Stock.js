import React, { Component } from 'react';
import './Stock.css';

class Stock extends Component {

  constructor(props) {
    super(props);
    const { symbol, price } = this.props.datistock;
    this.state = { symbol,
      price, 
      datatrade: 'XXXX-XX-XX 16:00:00', 
      ckrealtime: '' 
    };
  }

  static getDerivedStateFromProps(np,ns) {
    //  console.log('1fa) FIGLIO check props ');
     // if(np.datistock.quotazione !== ns.quotazione && np.datistock.nome!== ns.nome) {
     //   return { nome: np.datistock.nome, quotazione: np.datistock.quotazione };
     // }
      return null;
  }

  componentDidMount() {
     console.log('3f) FIGLIO DidMount ');
  }

  componentDidUpdate(pp,ps) {
    console.log('4f) FIGLIO – DidUpdate ' + this.props.datistock.nome);
    // if (pp.datistock.quotazione !== this.props.datistock.quotazione){
    //   this.setState((state,props) => 
    //                 ({ quotazione: props.datistock.quotazione }));
    // }
   }  

  getNewPrice = () => {
    // NB: Le API del sito worldtradingdata sono  cambiate quindi abbbiamo creato un'API di test nel nostro sito
    // Per maggiori informazioni leggi la news nell'area WebSU, dove hai scaricato questo codice
    const apiUrl = 'https://www.dcopelli.it/test/api/react/v1/intraday?symbol=' + this.props.datistock.symbol;
    fetch(apiUrl) 
    .then(r => r.json())
    .then(r => {
      const { intraday } = r;
      const timeprice = Object.entries(intraday)[0];
      const datatrade = timeprice[0];
      const price = timeprice[1].open;
      this.setState({ price, datatrade });
    }
    )
    .catch(error=>{console.log('Errore caricamento' + error)})
  }

  eliminoStock = () => {
    this.props.eliminoStock(this.props.datistock.id);
  }

  startRealTime = () => {
   this.timer = setInterval(() => this.getNewPrice(), 60000);
  } 

  stopRealTime = () => {
   clearInterval(this.timer);
  }

  startStopRealTime = () => {
  const ckrt = this.state.ckrealtime === 'checked' ? '' : 'checked';
    if (ckrt === 'checked') {
      this.startRealTime();
    } else {
      this.stopRealTime();
    }
  this.setState({ckrealtime: ckrt});
  }
  
  render() {
    const diff = this.state.price - this.props.datistock.price;
    const diffperc = this.props.datistock.price ? (diff/this.props.datistock.price) : 0;
    console.log('2f) FIGLIO Render ' + this.props.datistock.symbol);
    return (
      <div className="stock col-md-6">
      <div className="bodystock m-1 p-3">
      <i className="fas fa-times-circle closebtn" onClick={this.eliminoStock}></i>
      <div className="row">
        <div className="col-sm">
          <h2>{this.props.datistock.symbol}</h2>
          <p>Nasdaq</p>
        </div>
        <div className="col-sm">
          <h2>{this.state.price}</h2>
          <p>{this.state.datatrade.substr(11)}</p>
        </div>
        <div className="col-sm">
          <h2>{diffperc.toFixed(2)} %</h2>
          <p>{diff.toFixed(1)}</p>
        </div>
        <div className="col-sm">
        <h2>
          <i className="fas fa-sync-alt"></i>
        </h2>
        <label className="bs-switch">
          <input type="checkbox" 
                     checked={this.state.ckrealtime}
                     onChange={this.startStopRealTime} />
          <span className="slider round"></span>
        </label>
        </div>
      </div>
      </div>
      </div>
    )
  }
}

export default Stock

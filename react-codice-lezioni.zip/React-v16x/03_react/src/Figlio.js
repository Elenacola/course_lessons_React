import React, { Component } from 'react'

// class Figlio extends Component {
//   render() {
//     return (
//       <div>
//         <h1>Il sono il Figlio</h1>
//       </div>
//     )
//   }
// }

const Figlio = () => {
    return (
         <div>
            <h1>Mio Figlio</h1>
         </div>
    )
}

export default Figlio

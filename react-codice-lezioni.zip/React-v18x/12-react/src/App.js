import React, { Component } from 'react';
import './App.css';
import SearchForm from './SearchForm';

// Capitolo 12

class App extends Component {
  constructor(props) {
    super(props);
    this.state = { cerca : 'Apple'};
  }
  
  render() {
    console.log('2g) GENITORE: Render App');
    return (
      <div className="App">
        <header className="App-header">
          <p>
            Applicazione React 
          </p>
          <SearchForm />
        </header>  
      </div>
    );
  }
}

export default App;

import React, { Component } from 'react';

class SearchForm extends Component {
  constructor(props) {
    super(props);
    this.state = { cerca : 'Apple'};
  }

  onChangeCerca = (e) => {
    console.log(e.target.value);
    this.setState({cerca : e.target.value});
  }

  onChangeNote = (e) => {
    console.log(e.target.value);
    this.setState({ note : e.target.value});
  }
 
  render() {
    return (
      <div>
        <form>
         <input type="text" name="cerca"
                            value={this.state.cerca}
                            onChange={this.onChangeCerca}/>
         <textarea name="note" 
                            value={this.state.note}
                            onChangeNote={this.onChangeNote} /> 
        </form>
      </div>
    );
  }
} 

export default SearchForm;
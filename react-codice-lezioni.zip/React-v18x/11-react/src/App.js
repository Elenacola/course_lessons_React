import React, { Component } from 'react';
import './App.css';
import Stock from './Stock';

// Capitolo 11

class App extends Component {

  constructor(props) {
    super(props);
    this.state = {showMsg: false, maggiorenne: ''};
    //this.mostroMessaggio = this.mostroMessaggio.bind(this);  
  }

  showMaggiorenne = (nome) => {
    // valorizzo la variabile di stato maggiorenne
    this.setState({maggiorenne: nome});
  }


  mostroMessaggio = (evt) => {
     console.log('Ho cliccato sul tag p');
     this.setState({showMsg: true});
  }

  // mostroMessaggio(evt) {
  //   console.log('Ho cliccato sul tag p');
  //   this.setState({showMsg: true});
  // }

  render() {
    return (
      <div className="App">
        <header className="App-header">
          <p onClick={this.mostroMessaggio}>
            Applicazione React
          </p>
          { this.state.showMsg && <p>Messaggio nascosto</p> }
          <Stock nome="APPLE" 
                 fondatore="Jobs" 
                 eta={17}
                 showEta={this.showMaggiorenne} />
          <Stock nome="GOOGL" 
                 fondatore="Brin" 
                 eta={12}
                 showEta={this.showMaggiorenne} />
        <p>Figli Maggiorenni: {this.state.maggiorenne}</p>
        </header>
      </div>
    );
  }
}

export default App;

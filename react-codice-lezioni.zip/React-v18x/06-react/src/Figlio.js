import React, { Component } from 'react'

// Notazione delle classi
// class Figlio extends Component {
//  constructor(props) {
//    super(props);  
//  }
//   render() {
//     return (
//       <div>
//         <h1>Figlio</h1>
//       </div>
//     )
//   }
// }

// Notazione delle funzioni
const Figlio = (props) => {
    return (
         <div>
            <h1>Io sono il Figlio</h1>
         </div>
    )
}

// Notazione Hook
// const Figlio = (props) => {
//  return (
//       <div>
//          <h1>Io sono il Figlio</h1>
//       </div>
//  )
// }


export default Figlio;
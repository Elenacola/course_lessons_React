import React, { Component } from 'react';

class Stock extends Component {

  constructor(props) {
    super(props);
    const { nome, quotazione } = this.props.datistock;
    this.state = { nome, quotazione };
    console.log('1f) FIGLIO Creo istanza');
  }

  static getDerivedStateFromProps(np,ns) {
     console.log('1fa) FIGLIO check props ');
     if(np.datistock.quotazione !== ns.quotazione && np.datistock.nome!== ns.nome) {
       return { nome: np.datistock.nome, quotazione: np.datistock.quotazione };
     }
     return null;
  }

  componentDidMount() {
     console.log('3f) FIGLIO DidMount ');
  }

  componentDidUpdate(pp,ps) {
    console.log('4f) FIGLIO – DidUpdate ' + this.props.datistock.nome);
    // if (pp.datistock.quotazione !== this.props.datistock.quotazione){
    //   this.setState((state,props) => 
    //                 ({ quotazione: props.datistock.quotazione }));
    // }
   }  

  aggiornoStock = () => {
    this.setState((state,props) => ({ quotazione: state.quotazione + 10 }));
  }
 
  render() {
    console.log('2f) FIGLIO Render');
    return (
      <div className="stock col-md m-1 p-3">
      <div className="row">
        <div className="col-sm">
          <h2>{this.props.datistock.nome}</h2>
          <p>Nasdaq</p>
        </div>
        <div className="col-sm">
          <h2>{this.state.quotazione}</h2>
          <p>orario</p>
        </div>
        <div className="col-sm">
          <h2>DIFF</h2>
          <p>percentuale</p>
        </div>
        <div className="col-sm">
          <button onClick={this.aggiornoStock}>AGGIORNA</button>
        </div>
      </div>
      </div>
    )
  }
}

export default Stock

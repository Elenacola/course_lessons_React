import React, { Component } from 'react';
import './App.css';
import Stock from './Stock';

// Capitolo 15

class App extends Component {

  constructor(props) {
    super(props);
    console.log('1g) GENITORE: Creo istanza App');
    this.state = { listastock: [{nome : 'AAPL', quotazione : 250}] };
  }

  // CREAZIONE -------------------------------------------

  componentDidMount() {
    console.log('3g) GENITORE DidMount App');
    //interrogo l’API remota e aggiorno lo stato del componente
    //const stock = [{nome : 'AAPL', quotazione : 350}];
    //this.setState((props,state) => ({listastock: stock});
  }

  // AGGIORNAMENTO ---------------------------------------

   static getDerivedStateFromProps(np,ps) {
    console.log('4g) GENITORE - Controllo proprietà e stato precedenti');
    return null;
   }

  componentDidUpdate(prevProps) {
     console.log('4g) GENITORE - DidUpdate App');
  }

  //----------------------------------------------------------

  aggiornoStock = (e) => {
    e.preventDefault();
    const newstock = { nome: 'AMZN', quotazione: 1200 };
    this.setState({ listastock : [newstock] });
  }

  componentWillUnmount() {
    console.log('5g) GENITORE Componente App Distrutto');
  }


  render() {
    console.log('2g) GENITORE: Render App');
    return (
      <div className="App">
        <header className="App-header">
          <p>Applicazione Stock Quote</p>
          <button onClick={this.aggiornoStock}>TopStock</button>
          <div className="container">
            <div className="row">
              { this.state.listastock.map(el => <Stock datistock={el}/>) }
            </div>
          </div>
        </header>
      </div>

    );
  }
}

export default App;

import React, { Component } from 'react';
import './App.css';
import Stock from './Stock';
import StockHook from './StockHook';

// Capitolo 9

class App extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <p>
            Applicazione React
          </p>
          <StockHook nome="APPLE" fondatore="Jobs" eta={17}/>          
        </header>
      </div>
    );
  }
}

export default App;

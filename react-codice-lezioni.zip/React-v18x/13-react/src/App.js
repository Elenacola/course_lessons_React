import React, { Component } from 'react';
import './App.css';
import SearchForm from './SearchForm';
import SearchFormA from './SearchFormA';
import SearchFormB from './SearchFormB';
import SearchFormC from './SearchFormC';

// Capitolo 13

const test = true;
const testA = true;
const testB = true;
const testC = true;

class App extends Component {
  constructor(props) {
    super(props);
    this.state = { cerca : 'Apple'};
  }

  mostroDatiForm = (d) => {
   alert('Dato passato al componente Genitore App:' + d);
  }
  
  render() {
    console.log('2g) GENITORE: Render App');
    return (
      <div className="App">
        <header className="App-header">
          <p>
            Applicazione React 
          </p>
          {test && <SearchForm onSubmit={this.mostroDatiForm}/>}
          {testA && <SearchFormA onSubmit={this.mostroDatiForm}/>}
          {testB && <SearchFormB onSubmit={this.mostroDatiForm}/>}
          {testC && <SearchFormC onSubmit={this.mostroDatiForm}/>}
        </header>  
      </div>
    );
  }
}

export default App;

import React, { Component } from 'react';

class SearchForm extends Component {
  constructor(props) {
    super(props);
    this.state = { cerca : 'Apple'};
  }

  onChangeCerca = (e) => {
    console.log(e.target.value);
    this.setState({cerca : e.target.value});
  }

  invioForm = (e) => {
   e.preventDefault();
   //alert('Hai inserito il valore ' + e.target.elements.cerca.value);
   alert('Hai inserito il valore ' + this.state.cerca);
   this.props.onSubmit(this.state.cerca);
  }
 
  render() {
    return (
      <div>
        <form onSubmit={this.invioForm}>
         <input type="text" name="cerca"
                            value={this.state.cerca}
                            onChange={this.onChangeCerca}/>
         <input type="submit" value="Invio" />
        </form>
      </div>
    );
  }
} 

export default SearchForm;
import React, { Component } from 'react';

class SearchFormC extends Component {
  constructor(props) {
    super(props);
    this.state = { oggi : false, ieri: false };
  }

  onChangeRadio = (e) => {
    console.log('Hai selezionato il campo ' + e.target.name + ' ed è passato nella condizione ' + e.target.checked);
    this.setState({[e.target.name] : e.target.checked});
  }
 
  render() {
    return (
      <div>
          <input type="radio" name="oggi" checked={this.state.oggi} onChange={this.onChangeRadio}/> Oggi
          <input type="radio" name="ieri"  checked={this.state.ieri} onChange={this.onChangeRadio}/> Ieri
      </div>
    );
  }
} 

export default SearchFormC;
import React, { Component } from 'react';

class SearchFormA extends Component {
  constructor(props) {
    super(props);
    this.state = { azione: 'Google' };
  }

  onChangeSelect = (e) => {
    console.log(e.target.value);
    this.setState({ azione : e.target.value });
  }
 
  render() {
    return (
      <div>
        <select name="azioni" value={this.state.azione} onChange={this.onChangeSelect}>
         <option value="-">Seleziona</option>
         <option value="Apple">Apple</option>
         <option value="Google">Google</option>
        </select>
      </div>
    );
  }
} 

export default SearchFormA;
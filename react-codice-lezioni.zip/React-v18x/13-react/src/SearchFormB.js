import React, { Component } from 'react';

class SearchFormB extends Component {
  constructor(props) {
    super(props);
    this.state = { ck1 : false, ck2: false };
  }

  onChangeCk = (e) => {
    console.log('Hai selezionato il campo ' + e.target.name + ' ed è passato nella condizione ' + e.target.checked);
    this.setState({ [e.target.name] : e.target.checked});
  }
 
  render() {
    return (
    <div>
      <input type="checkbox" name="ck1" checked={this.state.ck1} onChange={this.onChangeCk} /> Campo 1 
      <input type="checkbox" name="ck2" checked={this.state.ck2} onChange={this.onChangeCk} /> Campo 2
    </div>
    );
  }
} 

export default SearchFormB;
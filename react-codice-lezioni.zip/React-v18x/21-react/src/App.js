import React, { Component } from 'react';
import './App.css';
import Cerca from './Cerca';

// Capitolo 21

class App extends Component {

  constructor(props) {
    super(props);
    this.state = { listastock: [{ nome : 'AAPL', quotazione : 250}], count: 1};
    console.log('1g) Creo istanza GENITORE');
  }
  
  cercaElementi = (strcerca) => {
    alert('Stai cercando ' + strcerca);
  }

  render() {
    console.log('2g) GENITORE  Render App');
    return (
      <div className="App container-fluid">
        <header className="App-header">
          <p>
            Applicazione NasdaqReact
          </p>
          <Cerca onInputSearch={this.cercaElementi} />
          <div className="container">
           <section className="listanomi">
              <div className="row">
                <div className="col">
         
                </div>  
              </div>
           </section>    
           <section className="listapreferiti">
              <div className="row">
                <div className="col">
                  
                </div>
              </div>
            </section>
          </div>     
        </header>
      </div>
    );
  }
}

export default App;

import React, { Component } from 'react';
import './App.css';
import Stock from './Stock'

// Capitolo 10

class App extends Component {

  constructor(props) {
    super(props);
    this.state = {showMsg: false};
    //this.mostroMessaggio = this.mostroMessaggio.bind(this);  
  }

  mostroMessaggio = (evt) => {
     console.log('Ho cliccato sul tag p');
     this.setState({showMsg: true});
  }

  // mostroMessaggio(evt) {
  //   console.log('Ho cliccato sul tag p');
  //   this.setState({showMsg: true});
  // }

  render() {
    return (
      <div className="App">
        <header className="App-header">
          <p onClick={this.mostroMessaggio}>
            Applicazione React
          </p>
          { this.state.showMsg && <p>Messaggio nascosto</p> }
          <Stock onClick={this.mostroMessaggio} nome="Apple" fondatore="Jobs" eta={17} />
        </header>
      </div>
    );
  }
}

export default App;

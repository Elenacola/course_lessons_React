import React, { Component } from 'react'

class Stock extends Component {
  constructor(props) {
      super(props);
      this.state = {eta : this.props.eta};
  }  

  aggiornoStato = () => {    
    this.setState((state,props) => ({eta: state.eta + 1}));
  }

  realTime = () => {
    setInterval(()=> this.aggiornoStato(), 3000);
  }

  render() {
    const { nome, fondatore } = this.props;
    return (
      <div>
        <h3>Figlio {nome.toUpperCase()} Età: {this.state.eta}</h3>
        <p>Fondatore: {fondatore} </p>
        <button onClick={this.realTime}>
            Aggiorno
        </button>
      </div>
    );
  }
}
export default Stock;

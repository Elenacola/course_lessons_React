import React, { useState,useEffect } from 'react';
import './App.css';
import StockHook from './StockHook';

// Capitolo 17

function App() {
  const [listastock, setListastock] = useState([{nome:'AAPL', eta:24, fondatore: 'Jobs',quotazione: 250}]);

  useEffect(()=>{
    console.log('3g) GENITORE DidMount ');
    return () => {
      console.log('5g) GENITORE:- Componente Distrutto'); 
    };
  },[])

  const aggiornoStock = (e) => {
    const stock = [{nome: 'AMZN', eta: 25, fondatore:'Jobs', quotazione: 1200}];
    setListastock(stock);
  }

  return (
    <div className="App container-fluid">
      <header className="App-header">
        <p>Applicazione Stock Quote</p>
        <button onClick={aggiornoStock}>TopStock</button>
        <div className="container mt-3">
             { listastock.map((el,index) => <StockHook datistock={el} key={el.nome}/>) }
        </div>
      </header>
    </div>
  );

}

export default App;

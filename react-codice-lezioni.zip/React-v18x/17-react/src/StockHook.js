import React, { useState, useEffect, useRef } from 'react';

function StockHook (props) {
  const [eta, setEta] = useState(props.datistock.eta);
  // const [hobby, setHobby] = useState(['Calcio','Tennis', 'Nuoto']);
  const [news, setNews] = useState([{titolo:'News', descrizione:'Bla bla'}]);
  const [start, setStart] = useState(false);
  const timerRef = useRef(null);

  console.log("Chiamata nella funzione: " + eta);

  const realTime = () => {    
    if (!start) {
      timerRef.current = setInterval(() => aggiornoStato(), 3000);
      setStart(!start);
    }
  }

  const aggiornoStato = () => {
    setEta(prevEta => prevEta+1);
  }

  useEffect(()=>{   
     console.log('Effetto in azione solo nel Mounting: ' + eta);
     return () => { 
                    clearInterval(timerRef.current)
                  };
  }, [])

  useEffect(() => {
    if (eta >= 18) {
      console.log('Sono maggiorenne: ' + eta);
    }
  }, [eta]);

  return (
      <div className="row">
        <h3>Figlio {props.datistock.nome}. Età {eta}</h3>
        <p>Fondatore {props.datistock.fondatore}</p>
        <p>{news[0].titolo} - {news[0].descrizione}</p>
        <button onClick={realTime}>
            Aggiorno
         </button>
       </div>
     );
}

export default StockHook;

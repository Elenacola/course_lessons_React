import React, {Component}  from 'react';
import PropTypes from 'prop-types';

// Notazione delle classi
class Stock extends Component {
 constructor(props) {
   super(props);
   this.hobby = ['Tennis','Calcio'];
 }
  render() {
    const { nome, fondatore, eta } = this.props;
    // incremento di uno, il valore di età ogni 3 secondi, ma non funziona!
    // vedi capitolo successivo
    setInterval(() => { eta++; console.log(eta++)}, 3000);
    return (
      <div>
        <h3>Figlio: {nome} - Età: {eta}</h3>
        <p>Fondatore: {fondatore}</p>
        <p> { eta>=18 ? 'Sono maggiorenne' : 'Sono minorenne'} </p> 
        {/* <p>Lista Hobby</p>
        <ul>
          { this.hobby.map(item => <li> {item} </li>) }
        </ul> */}
      </div>
    );
  }
}

// Notazione delle funzioni
// const Stock = ({nome, fondatore}) => {
//     const hobby = ['Tennis','Calcio'];
//     return (
//          <div>
//             <h3>Figlio {nome}</h3>
//             <p>Fondatore: {fondatore}</p>
//             <p>Lista Hobby</p> 
//             <ul>
//              { hobby.map(item => <li> {item} </li>) }
//             </ul>
//          </div>
//     );
// }

// Notazione Hook
// const Stock = (props) => {
//  const hobby = ['Tennis','Calcio'];
//  return (
//       <div>
//          <h3>Figlio {props.nome}</h3>
//          <p>Fondatore: {props.fondatore}</p>
//          <p>Lista Hobby</p> 
//          <ul>
//            { hobby.map(item => <li> {item} </li>) }
//          </ul>
//       </div>
//  );
// }

Stock.defaultProps = {
    nome: 'ND',
    fondatore: 'ND'
} 

Stock.propTypes = {
    nome: PropTypes.string,
    fondatore: PropTypes.string
}
   

export default Stock;
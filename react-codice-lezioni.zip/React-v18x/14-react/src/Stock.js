import React, { Component } from 'react';

class Stock extends Component {

  constructor(props) {
    super(props);
    const { nome, quotazione } = this.props.datistock;
    this.state = { quotazione };
    console.log('1f) FIGLIO - Creo istanza ' + nome);
  }

  //static getDerivedStateFromProps(np,ps) {
     //console.log('1fa) FIGLIO check props e state');
    // return null;
  //}

  componentDidMount() {
     console.log('3f) FIGLIO - DidMount ' + this.props.datistock.nome);
  }

  componentDidUpdate(pp,ps) {
    console.log('4f) FIGLIO – DidUpdate ' + this.props.datistock.nome);
    if (pp.datistock.quotazione !== this.props.datistock.quotazione){
      this.setState((state,props) => 
                    ({ quotazione: props.datistock.quotazione }));
    }
  }

  componentWillUnmount = () => {
    console.log('5g) - Componente Figlio Distrutto');
  }
  
  aggiornoStock = () => {
    this.setState((state,props) => ({ quotazione: state.quotazione + 10 }));
  }
 
  render() {
    console.log('2f) FIGLIO - Render ' + this.props.datistock.nome);
    return (
      <div className="stock col-md m-1 p-3">
      <div className="row">
        <div className="col-sm">
          <h2>{this.props.datistock.nome}</h2>
          <p>Nasdaq</p>
        </div>
        <div className="col-sm">
          <h2>{this.state.quotazione}</h2>
          <p>HH:MM:SS</p>
        </div>
        <div className="col-sm">
          <h2>Var</h2>
          <p>%</p>
        </div>
        <div className="col-sm">
          <button onClick={this.aggiornoStock}>AGGIORNA</button>
        </div>
      </div>
      </div>
    )
  }
}

export default Stock

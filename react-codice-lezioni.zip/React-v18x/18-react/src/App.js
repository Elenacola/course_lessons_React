import React, { Component } from 'react';
import './App.css';
import Stock from './Stock';

// Capitolo 18

class App extends Component {

  static count = 1;
 
  constructor(props) {
    super(props);
    this.state = { listastock: [{ nome : 'AAPL', quotazione : 250}], count: 1};
    console.log('1g) Creo istanza GENITORE');
  }
  
  // CREAZIONE -------------------------------------------
  
  componentDidMount() {
    console.log('3g) GENITORE DidMount ');
  }

  // AGGIORNAMENTO ---------------------------------------

  // static getDerivedStateFromProps(np,ps) {
  //   return null;
  // }

  componentDidUpdate(prevProps) {
     console.log('4g) GENITORE: DidUpdate App');
  }

  //----------------------------------------------------------

  aggiornoStock = (e) => {
    const stock = [{nome: 'AMZN', quotazione: 1200}];
    this.setState((state,props)=>({listastock : stock, count: state.count + 1}));
    console.log(this.state.count);
  }

  componentWillUnmount() {
     console.log('5g - Componente Distrutto');
  }

  render() {
    console.log('2g) GENITORE  Render App');
    return (
      <div className="App container-fluid">
        <header className="App-header">
          <p>
            Applicazione Stock Quote
          </p>
          <button onClick={this.aggiornoStock}>TopStock</button>
          <div className="container mt-3">
            <div className="row">
               { this.state.listastock.map((el,index) => <Stock datistock={el} key={this.state.count}/>) }
            </div>
          </div>
        </header>
      </div>
    );
  }
}

export default App;

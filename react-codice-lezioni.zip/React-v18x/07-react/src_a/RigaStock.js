import React  from 'react'

const RigaStock = (props) => {
 return (
      <div>
         <td>Colonna A</td>
         <td>Colonna B</td>
      </div>
 )
}

export default RigaStock;
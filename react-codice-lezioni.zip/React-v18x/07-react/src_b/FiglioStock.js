import React  from 'react';
import PropTypes from 'prop-types';

// Notazione delle classi
// class FiglioStock extends Component {
//  constructor(props) {
//    super(props);  
//  }
//   render() {
//     console.log('Proprietà passata ' + this.props.nome);
//     return (
//       <div>
//         <h1>Io sono il Figlio {this.props.nome}</h1>
//       </div>
//     )
//   }
// }

// Notazione delle funzioni
const FiglioStock = ({nome, fondatore}) => {
    console.log('Proprietà passata ' + nome);
    return (
         <div>
            <h1>Io sono il Figlio {nome}</h1>
            <p>Fondatore: {fondatore}</p>
         </div>
    );
}

// Notazione Hook
// const Figlio = (props) => {
//  console.log('Proprietà passata ' + props.nome);
//  return (
//       <div>
//          <h1>Io sono il Figlio {props.nome}</h1>
//       </div>
//  )
// }

FiglioStock.defaultProps = {
    nome: 'ND',
    fondatore: 'ND'
} 

FiglioStock.propTypes = {
    nome: PropTypes.string,
    fondatore: PropTypes.string
}
   

export default FiglioStock;
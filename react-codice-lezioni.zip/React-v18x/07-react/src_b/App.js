import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import FiglioStock from './FiglioStock';

class App extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <p>
            Applicazione React
          </p>
          <FiglioStock nome="APPLE" fondatore="Jobs" />
          <FiglioStock nome={3}/>
        </header>
      </div>
    );
  }
}

export default App;
